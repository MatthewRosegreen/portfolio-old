﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

namespace Rope_Burn
{
    

    public class Player
    {
        private int _score, _distance, _distanceReset, _speed,
            _lowerBounds, _upperBounds, _leftBounds, _rightBounds;
        public Vector2 position;
        private bool inMotionLeft, inMotionRight, isLeftDisabled;
        public CollisionSprite sprite;
        private Texture2D ninja_righthandup, ninja_lefthandup, ninja_leapright, ninja_leapleft, _previousState;
        private Keys key_left, key_right, key_hold;

        public Player(int x, int y, CollisionSprite spr, Keys k_left, Keys k_right, Keys k_hold,
            Texture2D texture_rhu, Texture2D texture_lhu, Texture2D texture_rl, Texture2D texture_ll)
        {
            _score = 0;
            position = new Vector2(x, y);
            inMotionLeft = false;
            inMotionRight = false;

            ninja_righthandup = texture_rhu;
            ninja_lefthandup = texture_lhu;
            ninja_leapright = texture_rl;
            ninja_leapleft = texture_ll;
            _previousState = texture_rhu;

            isLeftDisabled = false;
            _distanceReset = 120;
            _distance = 0;
            _speed = 10;
            sprite = spr;
            sprite.bounds.X = x;
            sprite.bounds.Y = y;
            key_left = k_left;
            key_right = k_right;
            key_hold = k_hold;
            _lowerBounds = 450;
            _upperBounds = 0;
            _leftBounds = -15;
            _rightBounds = 575;
        }

        public int GetScore()
        {
            return _score;
        }

        public void IncreaseScore(int amount)
        {
            _score += amount;
        }

        public void Update(InputHandler input)
        {
            if(!(inMotionLeft || inMotionRight))
            {
                if (input.IsHoldingKey(key_hold))
                {
                    _previousState = sprite.texture;
                    if (input.HasReleasedKey(key_left) && position.X > _leftBounds)
                    {
                        sprite.texture = ninja_leapleft;
                        _distance = _distanceReset;
                        inMotionLeft = true;
                    }
                    else if (input.HasReleasedKey(key_right) && position.X < _rightBounds)
                    {
                        sprite.texture = ninja_leapright;
                        _distance = _distanceReset;
                        inMotionRight = true;
                    }
                }
            }
            if (inMotionLeft)
            {
                position.X -= _speed;
                _distance -= _speed;
                if(_distance <= 0)
                {
                    sprite.texture = _previousState;
                    inMotionLeft = false;
                }
            }
            else if (inMotionRight)
            {
                position.X += _speed;
                _distance -= _speed;
                if (_distance <= 0)
                {
                    sprite.texture = _previousState;
                    inMotionRight = false;
                }
            }
            else if(input.HasReleasedKey(key_left) && !isLeftDisabled)
            {
                position.Y -= _speed;
                isLeftDisabled = true;
                sprite.texture = ninja_lefthandup;
            }
            else if (input.HasReleasedKey(key_right) && isLeftDisabled)
            {
                position.Y -= _speed;
                isLeftDisabled = false;
                sprite.texture = ninja_righthandup;
            }
            else if(position.Y < _lowerBounds)
            {
                position.Y++;
            }

            if(position.Y < _upperBounds)
            {
                position.Y = _upperBounds;
            }
            sprite.bounds.X = (int)position.X;
            sprite.bounds.Y = (int)position.Y;
        }
    }
}
