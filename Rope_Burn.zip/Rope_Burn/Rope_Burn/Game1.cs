﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;
using Microsoft.Xna.Framework.Media;

namespace Rope_Burn
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont spriteFont;
        SpriteFont spriteTitleFont;
        private Texture2D background, background2, textBackground,
            ninja_righthandup, ninja_lefthandup, ninja_leapright, ninja_leapleft;

        CollisionSprite player_sprite1;
        CollisionSprite player_sprite2;
        Clock timer;
        Rope rp;
        Segment chosen_segment;

        private InputHandler input;
        private string filename = "Content/highscore.txt";
        private bool menu = true;
        private bool hasStarted = false;
        private bool newWindow = true;
        private bool isMenuStatic = true;

        private Player p1;
        private Player p2;
        private string winnerMsg;
        private int winnerScore;
        private int highscore;
        private int textX = 805;
        private int menuX = 0;


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            //graphics.PreferredBackBufferWidth = 768;
            //graphics.PreferredBackBufferHeight = 576;
            graphics.PreferredBackBufferWidth = 925;
            graphics.PreferredBackBufferHeight = 480;
            Content.RootDirectory = "Content";

            // The InputHandler class is not part of XNA but has been written by Simon Schofield to help
            // parse user input. The class casn be found in the Solution Explorer
            input = new InputHandler();            
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            timer = new Clock();
            
            rp = new Rope();

            //Get highscore from file
            string file_line;
            try
            {
                var file = new StreamReader(filename);

                file_line = file.ReadLine();
                highscore = int.Parse(file_line);

                file.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                highscore = 0;
            }
                        
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            Song song = Content.Load<Song>("bensound-instinct");
            MediaPlayer.IsRepeating = true;
            MediaPlayer.Play(song);

            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            background = Content.Load<Texture2D>("background");
            background2 = Content.Load<Texture2D>("pexels-photo-402028");
            textBackground = Content.Load<Texture2D>("seg_black");

            ninja_righthandup = Content.Load<Texture2D>("ninja_righthandup");
            ninja_lefthandup = Content.Load<Texture2D>("ninja_lefthandup");
            ninja_leapright = Content.Load<Texture2D>("ninja_leapright");
            ninja_leapleft = Content.Load<Texture2D>("ninja_leapleft");

            spriteFont = Content.Load<SpriteFont>("font_small");
            spriteTitleFont = Content.Load<SpriteFont>("font");

            player_sprite1 = new CollisionSprite(Content.Load<Texture2D>("ninja_righthandup"), new Rectangle(120, 400, 60, 80));
            player_sprite2 = new CollisionSprite(Content.Load<Texture2D>("ninja_righthandup"), new Rectangle(360, 400, 60, 80));

            // TODO: use this.Content to load your game content here
        }


        protected void RopeLoad()
        {
            int screenHei = 480;
            int positionw = 0;
            int positionh = 0;
            for (int i = 0; i < rp.segments.Count; i++)
            {
                if ((positionh * 120) > (screenHei - 60))
                {
                    positionh = 0;
                    positionw++;
                }
                rp.segments[i] = new Segment(Content.Load<Texture2D>(rp.segments[i].filename), new Rectangle((positionw * 120), (positionh * 120), 30, 120), rp.segments[i].colour, "Rope " + (positionw + 1), "Segment " + (positionh + 1));

                positionh++;
            }
        }

        protected Segment RopeChoose()
        {
            var rng = new Random();
            return rp.segments[rng.Next(rp.segments.Count - 1)];
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            //spriteRenderer.Dispose();
            spriteBatch.Dispose();
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            double elapsed = (double)gameTime.ElapsedGameTime.TotalSeconds;

            // TODO: Add your game logic here
            timer.Update(gameTime);
            input.Update();

            if (menu)
            {
                if (menuX > 0)
                {
                    isMenuStatic = false;
                    menuX -= 10;
                }
                else
                {
                    isMenuStatic = true;
                    if (input.HasReleasedKey(Keys.Enter))
                        menu = false;
                }
            }
            else
            {
                if (!hasStarted)
                {
                    if (menuX < 800)
                    {
                        isMenuStatic = false;
                        menuX += 10;
                    }
                    else
                    {
                        isMenuStatic = true;
                        newWindow = false;

                        p1 = new Player(-15, 450, player_sprite1, Keys.Left, Keys.Right, Keys.NumPad0,
                            ninja_righthandup, ninja_lefthandup, ninja_leapright, ninja_leapleft);
                        p2 = new Player(105, 450, player_sprite2, Keys.A, Keys.D, Keys.G,
                            ninja_righthandup, ninja_lefthandup, ninja_leapright, ninja_leapleft);

                        rp.Reset();
                        RopeLoad();
                        chosen_segment = RopeChoose();

                        timer.SetCounter(15);
                        hasStarted = true;
                    }
                }
                else
                {
                    p1.Update(input);
                    p2.Update(input);
                    if (timer.isZero(gameTime))
                    {
                        var p1Increase = p1.sprite.boundingBoxIntersection(chosen_segment.sprite);
                        var p2Increase = p2.sprite.boundingBoxIntersection(chosen_segment.sprite);
                        if(p1Increase || p2Increase)
                        {
                            timer.SetCounter(15);
                            chosen_segment = RopeChoose();
                            if(p1Increase)
                                p1.IncreaseScore(1);
                            if (p2Increase)
                                p2.IncreaseScore(1);
                        }
                        else
                        {
                            var scoreP1 = p1.GetScore();
                            var scoreP2 = p2.GetScore();

                            if (scoreP1 > scoreP2)
                            {
                                winnerMsg = "P1 Wins";
                                winnerScore = scoreP1;
                            }
                            else if (scoreP1 < scoreP2)
                            {
                                winnerMsg = "P2 Wins";
                                winnerScore = scoreP2;
                            }
                            else
                            {
                                winnerMsg = "  Draw";
                                winnerScore = scoreP1;
                            }

                            if (winnerScore > highscore)
                            {
                                try
                                {
                                    var file = new StreamWriter(filename);
                                    file.WriteLine(winnerScore);
                                    file.Close();
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e);
                                }
                                highscore = winnerScore;
                            }

                            menu = true;
                            hasStarted = false;
                        }
                    }
                }
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.LightBlue);

            // TODO: Add your drawing code here
            int screenHei = 480;
            int screenWid = 800;
            spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend);
            spriteBatch.Draw(background, new Rectangle(0, 0, screenWid, screenHei), Color.White);
            spriteBatch.Draw(background2, new Rectangle(menuX, 0, 925, screenHei), Color.White);
            if (isMenuStatic)
            {
                if (menu)
                {
                    spriteBatch.DrawString(spriteTitleFont, "Scurry", new Vector2(400, 150), Color.White);
                    spriteBatch.DrawString(spriteFont, "A Game By Matthew Rosegreen", new Vector2(315, 170), Color.White);
                    spriteBatch.DrawString(spriteFont, $"High Score: {highscore.ToString()}", new Vector2(375, newWindow ? 250 : 300), Color.White);
                    spriteBatch.Draw(textBackground, new Rectangle(0, 425, 350, 50), Color.White);
                    spriteBatch.DrawString(spriteFont, "Music: www.bensound.com", new Vector2(10, 430), Color.White);
                    spriteBatch.DrawString(spriteFont, "Images: www.pexels.com - www.gameart2d.com", new Vector2(10, 450), Color.White);
                    if (!newWindow)
                    {                    
                        spriteBatch.DrawString(spriteTitleFont, winnerMsg, new Vector2(390, 200), Color.White);
                        spriteBatch.DrawString(spriteTitleFont, "Your Scores:", new Vector2(370, 250), Color.White);
                        spriteBatch.DrawString(spriteTitleFont, p1.GetScore().ToString(), new Vector2(385, 270), Color.White);
                        spriteBatch.DrawString(spriteTitleFont, "-", new Vector2(415, 270), Color.White);
                        spriteBatch.DrawString(spriteTitleFont, p2.GetScore().ToString(), new Vector2(445, 270), Color.White);
                    }
                }
                else if (hasStarted)
                {
                    for (int i = 0; i < rp.segments.Count; i++)
                        rp.segments[i].sprite.Draw(spriteBatch);
                    spriteBatch.DrawString(spriteFont, $"Timer: {timer.timeLeft}", new Vector2(textX, 50), Color.Black);
                    spriteBatch.DrawString(spriteFont, $"High Score: {highscore.ToString()}", new Vector2(textX, 80), Color.Black);
                    spriteBatch.DrawString(spriteFont, $"P1 Score: {p1.GetScore().ToString()}", new Vector2(textX, 110), Color.Black);
                    spriteBatch.DrawString(spriteFont, $"P2 Score: {p2.GetScore().ToString()}", new Vector2(textX, 140), Color.Black);
                    spriteBatch.DrawString(spriteFont, $"Get to: {chosen_segment.colour}", new Vector2(textX, 220), Color.Black);
                    if (timer.timeLeftInt <= 10)
                        spriteBatch.DrawString(spriteFont, chosen_segment.first_clue, new Vector2(textX, 260), Color.Gray);
                    if(timer.timeLeftInt <= 5)
                        spriteBatch.DrawString(spriteFont, chosen_segment.second_clue, new Vector2(textX, 290), Color.Gray);
                    p1.sprite.Draw(spriteBatch);
                    p2.sprite.Draw(spriteBatch);
                }
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
