﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rope_Burn
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.Xna.Framework;
    using Microsoft.Xna.Framework.Audio;
    using Microsoft.Xna.Framework.Content;
    //using Microsoft.Xna.Framework.GamerServices;
    using Microsoft.Xna.Framework.Graphics;
    using Microsoft.Xna.Framework.Input;
    using Microsoft.Xna.Framework.Media;
    //using Microsoft.Xna.Framework.Net;
    //using Microsoft.Xna.Framework.Storage;


    public class CollisionSprite
    {
        public Rectangle bounds;
        public Color color;
        public Texture2D texture;
        private uint[] rawData;


        public CollisionSprite(Texture2D Tex, Rectangle Bounds)
        {
            texture = Tex;
            bounds = Bounds;
            color = Color.White;
            rawData = new uint[texture.Width * texture.Height];
            texture.GetData<uint>(rawData);
        }



        public bool boundingBoxIntersection(CollisionSprite b)
        {
            // check if two Rectangles intersect
            return (bounds.Right > b.bounds.Left && bounds.Left < b.bounds.Right &&
                    bounds.Bottom > b.bounds.Top && bounds.Top < b.bounds.Bottom);
        }

        public bool visiblePixelCollision(CollisionSprite b)
        {
            if (boundingBoxIntersection(b))
            {


                int x1 = Math.Max(bounds.X, b.bounds.X);
                int x2 = Math.Min(bounds.X + bounds.Width, b.bounds.X + b.bounds.Width);

                int y1 = Math.Max(bounds.Y, b.bounds.Y);
                int y2 = Math.Min(bounds.Y + bounds.Height, b.bounds.Y + b.bounds.Height);

                for (int y = y1; y < y2; ++y)
                {
                    for (int x = x1; x < x2; ++x)
                    {

                        // start of slow and understandable version
                        int thisX = (x - bounds.X);
                        int thisY = (y - bounds.Y);
                        int bX = (x - b.bounds.X);
                        int bY = (y - b.bounds.Y);

                        Color thisPixelValues = getPixel(thisX, thisY);
                        Color bPixelValues = b.getPixel(bX, bY);

                        // compares the Alpha of each pixel to see if they are both visible
                        if (thisPixelValues.A > 20 && bPixelValues.A > 20)
                        {
                            return true;
                        }

                        // end of slow understandable version
                    }
                }
            }

            return false;
        }

        // get pixel syntax used by slow version
        private Color getPixel(int x, int y)
        {

            Color retrievedColor = new Color();

            int targetPixelIndex = texture.Width * y + x;
            uint packedColour = rawData[targetPixelIndex];

            retrievedColor.B = (byte)(packedColour);
            retrievedColor.G = (byte)(packedColour >> 8);
            retrievedColor.R = (byte)(packedColour >> 16);
            retrievedColor.A = (byte)(packedColour >> 24);

            return retrievedColor;
        }


        public void Draw(SpriteBatch sb)
        {
            sb.Draw(texture, bounds, color);
        }
    }
}
