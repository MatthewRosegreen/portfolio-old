﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
namespace Rope_Burn
{
    class Clock
    {
        public string timeLeft;
        public int timeLeftInt;

        public TimeSpan cTimer;

        public Clock()
        {
            timeLeftInt = 0;
            timeLeft = "0";
        }

        public void SetCounter(int start)
        {
            cTimer = TimeSpan.FromSeconds(start);
        }
        public bool isZero(GameTime gameTime)
        {
            return cTimer < TimeSpan.Zero;
        }
        public void Update(GameTime gameTime)
        {
            cTimer -= gameTime.ElapsedGameTime;
            timeLeftInt = cTimer.Seconds + 1;
            timeLeft = timeLeftInt.ToString();
        }
    }
}
