﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


namespace Rope_Burn
{
    public class Rope
    {
        private Random rng;
        private List<Segment> segments_full;
        public List<Segment> segments;

        public Rope()
        {
            rng = new Random();
            var segs = new string[] { "Azure", "Black", "Blue", "Brown",
                "Chocolate", "Cream", "Crimson", "Fawn","Gold",
                "Green", "Grey", "Lemon", "Lilac", "Mauve",
                "Ochre", "Olive", "Orange", "Peach", "Pink",
                "Purple", "Red", "Rose", "Ruby", "Russet",
                "Scarlet", "Silver", "Violet", "White", "Yellow" };

            segments = new List<Segment>();
            segments_full = new List<Segment>();

            for (int i = 0; i < segs.Length; i++)
            {
                segments_full.Add(new Segment());
                segments_full[i].colour = segs[i];
                segments_full[i].filename = $"seg_{segs[i]}";
            }
            segments.AddRange(segments_full);
            segments.RemoveAt(0);
        }

        public void Reset()
        {
            var _segments = new List<Segment>();
            segments = new List<Segment>(segments_full);

            var seg_count = segments.Count;
            for(int i = 0; i < seg_count - 1; i++)
            {
                int rdm = rng.Next(segments.Count - 1);
                _segments.Add(segments[rdm]);
                segments.RemoveAt(rdm);                
            }
            segments.RemoveAt(0);
            segments.AddRange(_segments);
        }
    }

    public class Segment
    {
        public CollisionSprite sprite;
        public string filename, colour, first_clue, second_clue;

        public Segment()
        {
            //returns nothing
        }

        public Segment(Texture2D Tex, Rectangle Bounds, string Colour, string First_Clue, string Second_Clue)
        {
            sprite = new CollisionSprite(Tex, Bounds);
            filename = $"seg_{Colour.ToLower()}";
            colour = Colour;
            first_clue = First_Clue;
            second_clue = Second_Clue;
        }
    }
}
